Elite Booster - Android project (Kotlin, minSdk 26)

Build APK with GitHub Actions: push this project (workflow is in .github/workflows/build.yml),
open the Actions tab, download the artifact "EliteBooster-APK" -> app-debug.apk

Or open in Android Studio and run Build > Build APK(s).
