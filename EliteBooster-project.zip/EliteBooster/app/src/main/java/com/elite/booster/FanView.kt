package com.elite.booster

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

class FanView(context: Context) : View(context) {

    private val red = Color.parseColor("#FF1E1E")
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bladePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hubPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hubRing = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blade = Path()

    var glow: Boolean = false
        set(value) {
            field = value
            val radius = if (value) 28f else 0f
            ringPaint.setShadowLayer(radius, 0f, 0f, red)
            bladePaint.setShadowLayer(radius, 0f, 0f, red)
            invalidate()
        }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        bgPaint.color = Color.parseColor("#1A0000")
        bgPaint.style = Paint.Style.FILL
        ringPaint.color = red
        ringPaint.style = Paint.Style.STROKE
        ringPaint.strokeWidth = 10f
        bladePaint.color = red
        bladePaint.style = Paint.Style.FILL
        hubPaint.color = Color.parseColor("#0A0000")
        hubPaint.style = Paint.Style.FILL
        hubRing.color = red
        hubRing.style = Paint.Style.STROKE
        hubRing.strokeWidth = 4f
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 40f

        canvas.drawCircle(cx, cy, r, bgPaint)
        canvas.drawCircle(cx, cy, r, ringPaint)

        blade.reset()
        blade.moveTo(0f, -r * 0.15f)
        blade.cubicTo(r * 0.45f, -r * 0.25f, r * 0.5f, -r * 0.65f, r * 0.12f, -r * 0.82f)
        blade.cubicTo(-r * 0.12f, -r * 0.55f, -r * 0.12f, -r * 0.3f, 0f, -r * 0.15f)
        blade.close()

        for (i in 0 until 5) {
            canvas.save()
            canvas.rotate(i * 72f, cx, cy)
            canvas.translate(cx, cy)
            canvas.drawPath(blade, bladePaint)
            canvas.restore()
        }

        canvas.drawCircle(cx, cy, r * 0.13f, hubPaint)
        canvas.drawCircle(cx, cy, r * 0.13f, hubRing)
    }
}
