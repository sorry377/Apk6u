package com.elite.booster

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.LinearInterpolator
import android.view.animation.RotateAnimation
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val red = Color.parseColor("#FF1E1E")
    private val softRed = Color.parseColor("#FF8080")
    private val darkRed = Color.parseColor("#1A0000")

    private lateinit var status: TextView
    private lateinit var fan: FanView
    private val buttons = HashMap<String, Button>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = ScrollView(this)
        root.setBackgroundColor(Color.parseColor("#0A0000"))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(20), dp(40), dp(20), dp(40))
        root.addView(col)

        val title = TextView(this)
        title.text = "ELITE BOOSTER"
        title.textSize = 30f
        title.setTextColor(red)
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.15f
        title.setShadowLayer(24f, 0f, 0f, red)
        col.addView(title)

        val bar = View(this)
        bar.setBackgroundColor(red)
        val barLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(2))
        barLp.topMargin = dp(10)
        col.addView(bar, barLp)

        fan = FanView(this)
        fan.setOnClickListener { toggleBoost() }
        val fanLp = LinearLayout.LayoutParams(dp(200), dp(200))
        fanLp.topMargin = dp(30)
        fanLp.bottomMargin = dp(10)
        col.addView(fan, fanLp)

        status = TextView(this)
        status.setTextColor(softRed)
        status.gravity = Gravity.CENTER
        col.addView(status)

        addButton(col, "cross") { toggle("cross") }
        addButton(col, "fps") { toggle("fps") }
        addButton(col, "smooth") { toggle("smooth") }

        val sliderTitle = TextView(this)
        sliderTitle.text = "ปรับเป้ากลางจอ"
        sliderTitle.textSize = 18f
        sliderTitle.setTextColor(red)
        sliderTitle.typeface = Typeface.DEFAULT_BOLD
        sliderTitle.setPadding(0, dp(28), 0, 0)
        col.addView(sliderTitle)

        addSlider(col, "ขนาด", 20, 200, OverlayService.sizeDp) { OverlayService.sizeDp = it }
        addSlider(col, "ความโปร่งใส", 20, 255, OverlayService.alpha) { OverlayService.alpha = it }
        addSlider(col, "ซ้าย - ขวา", -300, 300, OverlayService.offX) { OverlayService.offX = it }
        addSlider(col, "บน - ล่าง", -300, 300, OverlayService.offY) { OverlayService.offY = it }

        setContentView(root)
        syncUi()
    }

    override fun onResume() {
        super.onResume()
        syncUi()
        if (!OverlayService.boost) {
            status.text = if (ShizukuHelper.ready()) {
                "Shizuku เชื่อมต่อแล้ว ✔ (โหมดเต็ม)"
            } else {
                "Shizuku ยังไม่พร้อม (โหมดพื้นฐาน)"
            }
        }
    }

    // ---------------- actions ----------------

    private fun toggle(which: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "อนุญาต 'แสดงทับแอพอื่น' แล้วกลับมากดใหม่", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        when (which) {
            "cross" -> OverlayService.crossOn = !OverlayService.crossOn
            "fps" -> {
                OverlayService.fpsOn = !OverlayService.fpsOn
                if (OverlayService.fpsOn) ShizukuHelper.requestPermission()
            }
            "smooth" -> OverlayService.smooth = !OverlayService.smooth
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        syncUi()
    }

    private fun toggleBoost() {
        if (!OverlayService.boost) {
            ShizukuHelper.requestPermission()
            OverlayService.boost = true
            status.text = "กำลังล้าง RAM..."
            startForegroundService(Intent(this, OverlayService::class.java))
            syncUi()
            clearRam { mb ->
                if (OverlayService.boost) {
                    val mode = if (ShizukuHelper.ready()) " + Shizuku" else ""
                    status.text = "BOOST ON ✔  ล้าง RAM ได้ ~$mb MB$mode"
                }
            }
        } else {
            OverlayService.boost = false
            startForegroundService(Intent(this, OverlayService::class.java))
            status.text = "ปิด Boost แล้ว"
            syncUi()
        }
    }

    private fun clearRam(done: (Long) -> Unit) {
        Thread {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val before = mi.availMem
            packageManager.getInstalledApplications(0)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != packageName }
                .forEach { am.killBackgroundProcesses(it.packageName) }
            try {
                Thread.sleep(400)
            } catch (e: InterruptedException) {
            }
            am.getMemoryInfo(mi)
            val freed = ((mi.availMem - before) / 1048576L).coerceAtLeast(0L)
            runOnUiThread { done(freed) }
        }.start()
    }

    // ---------------- UI helpers ----------------

    private fun syncUi() {
        setBtn("cross", "เป้ากลางจอ", OverlayService.crossOn)
        setBtn("fps", "แสดง FPS", OverlayService.fpsOn)
        setBtn("smooth", "SMOOTH (รีเฟรชเรตสูงสุด)", OverlayService.smooth)

        fan.glow = OverlayService.boost
        if (OverlayService.boost) {
            if (fan.animation == null) {
                val a = RotateAnimation(
                    0f, 360f,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f
                )
                a.duration = 400
                a.repeatCount = Animation.INFINITE
                a.interpolator = LinearInterpolator()
                fan.startAnimation(a)
            }
        } else {
            fan.clearAnimation()
        }
    }

    private fun setBtn(key: String, label: String, on: Boolean) {
        val b = buttons[key] ?: return
        val state = if (on) "เปิด" else "ปิด"
        b.text = "$label: $state"
        val bg = GradientDrawable()
        bg.cornerRadius = 20f
        bg.setColor(if (on) red else darkRed)
        bg.setStroke(3, red)
        b.background = bg
        b.setTextColor(if (on) Color.BLACK else red)
    }

    private fun addButton(parent: LinearLayout, key: String, onClick: () -> Unit) {
        val b = Button(this)
        b.setAllCaps(false)
        b.typeface = Typeface.DEFAULT_BOLD
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(12)
        parent.addView(b, lp)
        buttons[key] = b
    }

    private fun addSlider(
        parent: LinearLayout,
        label: String,
        lo: Int,
        hi: Int,
        start: Int,
        onChange: (Int) -> Unit
    ) {
        val name = TextView(this)
        name.text = label
        name.setTextColor(softRed)
        name.setPadding(0, dp(10), 0, 0)
        parent.addView(name)

        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = start - lo
        sb.progressTintList = ColorStateList.valueOf(red)
        sb.thumbTintList = ColorStateList.valueOf(red)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onChange(progress + lo)
                OverlayService.instance?.refresh()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        parent.addView(
            sb,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
    }
}
