package com.elite.booster

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuHelper {

    private val pkgRegex = Regex("([A-Za-z][A-Za-z0-9_.]*)/[A-Za-z0-9_.$]+")

    private var cachedPkg = ""
    private var cachedLayer = ""
    private var cachedAt = 0L

    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(100)
            }
        } catch (e: Throwable) {
        }
    }

    /** Run a shell command through Shizuku (shell-level privileges, no root). */
    fun run(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Throwable) {
        ""
    }

    fun foregroundPkg(): String? {
        val lines = run("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'").lines()
        val line = lines.firstOrNull { it.contains("mCurrentFocus") && it.contains("/") }
            ?: lines.firstOrNull { it.contains("mFocusedApp") && it.contains("/") }
            ?: return null
        return pkgRegex.find(line)?.groupValues?.get(1)
    }

    /** Real FPS of the app in the foreground, or -1 if it cannot be read on this device. */
    fun gameFps(): Int {
        val pkg = foregroundPkg() ?: return -1
        val now = System.currentTimeMillis()

        if (pkg != cachedPkg || cachedLayer.isEmpty() || now - cachedAt > 15000L) {
            val layers = run("dumpsys SurfaceFlinger --list").lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
            val layer = layers.firstOrNull { it.contains(pkg) && it.contains("SurfaceView") && !it.contains("Background") }
                ?: layers.firstOrNull { it.contains(pkg) && !it.contains("Background") }
                ?: return -1
            cachedPkg = pkg
            cachedLayer = layer
            cachedAt = now
        }

        val out = run("dumpsys SurfaceFlinger --latency '$cachedLayer'").lines()
        val stamps = ArrayList<Long>()
        for (i in 1 until out.size) {
            val parts = out[i].trim().split(Regex("\\s+"))
            if (parts.size >= 3) {
                val v = parts[1].toLongOrNull()
                if (v != null && v > 0L && v != Long.MAX_VALUE) stamps.add(v)
            }
        }
        if (stamps.size < 2) {
            cachedLayer = ""
            return -1
        }
        val end = stamps.maxOrNull() ?: return -1
        return stamps.count { it > end - 1_000_000_000L }
    }

    /** System-level boost. Commands a device does not support are simply ignored. */
    fun boostSystem() {
        run("am kill-all")
        run("cmd power set-fixed-performance-mode-enabled true")
        run("cmd thermalservice override-status 0")
        run("settings put global low_power 0")
    }

    fun boostGame(pkg: String) {
        run("cmd game mode performance $pkg")
    }

    fun resetBoost() {
        run("cmd power set-fixed-performance-mode-enabled false")
        run("cmd thermalservice reset")
    }
}
