package com.elite.booster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.view.Choreographer
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class CrossView(context: Context) : View(context) {

    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        line.color = Color.parseColor("#FF1E1E")
        line.style = Paint.Style.STROKE
        line.strokeWidth = 4f
        dot.color = Color.parseColor("#FF1E1E")
        dot.style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        val a = OverlayService.alpha
        line.alpha = a
        dot.alpha = a
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 6f
        canvas.drawCircle(cx, cy, r * 0.55f, line)
        canvas.drawLine(cx - r, cy, cx - r * 0.25f, cy, line)
        canvas.drawLine(cx + r * 0.25f, cy, cx + r, cy, line)
        canvas.drawLine(cx, cy - r, cx, cy - r * 0.25f, line)
        canvas.drawLine(cx, cy + r * 0.25f, cx, cy + r, line)
        canvas.drawCircle(cx, cy, 5f, dot)
    }
}

class OverlayService : Service() {

    companion object {
        @Volatile var crossOn = false
        @Volatile var fpsOn = false
        @Volatile var smooth = false
        @Volatile var boost = false
        @Volatile var sizeDp = 60
        @Volatile var alpha = 255
        @Volatile var offX = 0
        @Volatile var offY = 0
        @Volatile var instance: OverlayService? = null
    }

    private lateinit var wm: WindowManager
    private var cross: CrossView? = null
    private var fpsText: TextView? = null
    private var smoothView: View? = null
    private var wake: PowerManager.WakeLock? = null

    private var frames = 0
    private var lastTick = 0L
    private var ticking = false

    @Volatile private var polling = false
    @Volatile private var fpsGen = 0
    @Volatile private var boosting = false
    @Volatile private var boostGen = 0

    private val tick = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!ticking) return
            if (lastTick == 0L) lastTick = frameTimeNanos
            frames++
            if (frameTimeNanos - lastTick >= 1_000_000_000L) {
                if (!ShizukuHelper.ready()) fpsText?.text = "SCREEN FPS $frames"
                frames = 0
                lastTick = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("elite", "Elite Booster", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "elite")
            .setContentTitle("Elite Booster ทำงานอยู่")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        refresh()
        return START_NOT_STICKY
    }

    private fun overlayParams(w: Int, h: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (smooth) {
            try {
                val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
                val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
                if (display != null) {
                    val cur = display.mode
                    val best = display.supportedModes
                        .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                        .maxByOrNull { it.refreshRate }
                    if (best != null) lp.preferredDisplayModeId = best.modeId
                }
            } catch (e: Exception) {
            }
        }
        return lp
    }

    fun refresh() {
        val density = resources.displayMetrics.density

        try {
            // ----- Crosshair -----
            if (crossOn) {
                val px = (sizeDp * density).toInt()
                val lp = overlayParams(px, px)
                lp.gravity = Gravity.CENTER
                lp.x = (offX * density).toInt()
                lp.y = (offY * density).toInt()
                val existing = cross
                if (existing == null) {
                    val v = CrossView(this)
                    cross = v
                    wm.addView(v, lp)
                } else {
                    wm.updateViewLayout(existing, lp)
                    existing.invalidate()
                }
            } else {
                cross?.let { wm.removeView(it) }
                cross = null
            }

            // ----- FPS counter -----
            if (fpsOn) {
                val lp = overlayParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT
                )
                lp.gravity = Gravity.TOP or Gravity.START
                lp.x = 20
                lp.y = 60
                val existing = fpsText
                if (existing == null) {
                    val tv = TextView(this)
                    tv.setTextColor(Color.parseColor("#FF1E1E"))
                    tv.textSize = 16f
                    tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
                    tv.setBackgroundColor(Color.parseColor("#99000000"))
                    tv.setPadding(16, 6, 16, 6)
                    tv.text = "FPS --"
                    fpsText = tv
                    wm.addView(tv, lp)
                    startFps()
                } else {
                    wm.updateViewLayout(existing, lp)
                }
            } else if (fpsText != null) {
                stopFps()
                fpsText?.let { wm.removeView(it) }
                fpsText = null
            }

            // ----- Smooth: 1px invisible window that asks for the highest refresh rate -----
            if (smooth) {
                val lp = overlayParams(1, 1)
                lp.gravity = Gravity.TOP or Gravity.START
                val existing = smoothView
                if (existing == null) {
                    val v = View(this)
                    smoothView = v
                    wm.addView(v, lp)
                } else {
                    wm.updateViewLayout(existing, lp)
                }
            } else {
                smoothView?.let { wm.removeView(it) }
                smoothView = null
            }
        } catch (e: Exception) {
            // overlay permission revoked or window error: turn overlay features off
            crossOn = false
            fpsOn = false
            smooth = false
        }

        if (boost) startBoost() else stopBoost()

        if (!crossOn && !fpsOn && !smooth && !boost) stopSelf()
    }

    // ---------------- FPS ----------------

    private fun startFps() {
        frames = 0
        lastTick = 0L
        ticking = true
        Choreographer.getInstance().postFrameCallback(tick)

        polling = true
        val gen = ++fpsGen
        Thread {
            while (polling && gen == fpsGen) {
                if (ShizukuHelper.ready()) {
                    val fps = ShizukuHelper.gameFps()
                    val label = if (fps >= 0) "GAME FPS $fps" else "GAME FPS --"
                    fpsText?.post { fpsText?.text = label }
                }
                try {
                    Thread.sleep(1000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
    }

    private fun stopFps() {
        ticking = false
        polling = false
        Choreographer.getInstance().removeFrameCallback(tick)
    }

    // ---------------- Boost ----------------

    private fun startBoost() {
        if (boosting) return
        boosting = true

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "elite:boost")
        w.acquire(6 * 60 * 60 * 1000L)
        wake = w

        val gen = ++boostGen
        Thread {
            var applied = false
            var lastPkg = ""
            while (boosting && gen == boostGen) {
                if (ShizukuHelper.ready()) {
                    if (!applied) {
                        ShizukuHelper.boostSystem()
                        applied = true
                    }
                    val pkg = ShizukuHelper.foregroundPkg()
                    if (pkg != null && pkg != packageName && pkg != lastPkg &&
                        !pkg.contains("launcher") && !pkg.startsWith("com.android.systemui")
                    ) {
                        ShizukuHelper.boostGame(pkg)
                        lastPkg = pkg
                    }
                }
                try {
                    Thread.sleep(3000)
                } catch (e: InterruptedException) {
                    break
                }
            }
            if (applied && gen == boostGen) ShizukuHelper.resetBoost()
        }.start()
    }

    private fun stopBoost() {
        boosting = false
        wake?.let { if (it.isHeld) it.release() }
        wake = null
    }

    override fun onDestroy() {
        stopFps()
        stopBoost()
        try {
            cross?.let { wm.removeView(it) }
            fpsText?.let { wm.removeView(it) }
            smoothView?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        cross = null
        fpsText = null
        smoothView = null
        instance = null
        super.onDestroy()
    }
}
